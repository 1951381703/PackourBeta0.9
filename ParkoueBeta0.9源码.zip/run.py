# coding: utf-8

import sys
from core.core import main

main()